﻿using UnityEngine;
using System.Collections;

public class CharacterControls : MonoBehaviour {

	private float moveSpeed = 3.0f;
	private float moveVelocity = 2.0f;
	private float jumpHeight = 6.0f;
	private Rigidbody rb;
	private isGrounded ground;

	// Use this for initialization
	void Start () 
	{
		rb = GetComponent<Rigidbody> ();
		ground = GetComponent<isGrounded> ();
	}

	// Update is called once per frame
	void Update () 
	{
		if (Input.GetKey (KeyCode.D))
			MoveRight ();

		if (Input.GetKey (KeyCode.A))
			MoveLeft ();

		if (Input.GetKey (KeyCode.Space) && ground.Grounded())
			Jump ();
	}

	void FixedUpdate ()
	{
		
	}

	void MoveRight()
	{
		rb.velocity = new Vector2 (moveSpeed, rb.velocity.y);
		moveVelocity = moveSpeed;
	}

	void MoveLeft()
	{
		rb.velocity = new Vector2 (-moveSpeed, rb.velocity.y);
		moveVelocity = -moveSpeed;
	}

	void Jump()
	{
		rb.velocity = new Vector2 (rb.velocity.x, jumpHeight);
	}
	

}
