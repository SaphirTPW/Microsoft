﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class HealthManager : MonoBehaviour {

	public int maxPlayerHealth;
	public static int playerHealth;
	public Slider healthBar;
	private LevelManager levelmanager;
	public bool isDead;

	// Use this for initialization
	void Start () 
	{
		healthBar = GetComponent<Slider> ();
		levelmanager = FindObjectOfType<LevelManager> ();
		isDead = false;
	}
	
	// Update is called once per frame
	void Update () 
	{
		if (playerHealth <= 0 && !isDead) 
		{
			playerHealth = 0;
			levelmanager.RespawnPlayer ();
			isDead = true;
		}

		if (playerHealth > maxPlayerHealth)
			FullHealth();

		healthBar.value = playerHealth;
	}

	public static void HurtPlayer(int damageToGive)
	{
		playerHealth -= damageToGive;
	}

	public void FullHealth()
	{
		playerHealth = maxPlayerHealth;
	}
}
